package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class paymentPageBean {
	WebDriver driver;
	@FindBy(name="name",how=How.NAME)
	private WebElement name;
	@FindBy(name="cardNo")
	private WebElement cardNo;
	@FindBy(name="cvvNo")
	private WebElement cvvNo;
	@FindBy(name="exDate")
	private WebElement exDate;
	
	@FindBy(name="pay")
	private WebElement pay;
	
	
	public paymentPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setName(String Name) {

		name.sendKeys(Name);
	}
	public void setCardNo(String CardNo) {
		
		cardNo.sendKeys(CardNo);
	}
	public void setCvvNo(String CvvNo) {

		cvvNo.sendKeys(CvvNo);
	}
	public void setExDate(String ExDate) {
		exDate.sendKeys(ExDate);
	}
	
	public void setPayPage() {
		pay.submit();
		
	}
	
	public void navigateTo_NextPage(String Name, String CardNo, String CvvNo, String ExDate) {
		this.setName(Name);
		this.setCardNo(CardNo);
		this.setCvvNo(CvvNo);
		this.setExDate(ExDate);
		this.setPayPage();
	}
	
}

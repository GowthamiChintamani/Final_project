package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class studentPageBean {
	WebDriver driver;
	@FindBy(name="firstName",how=How.NAME)
	private WebElement firstname;
	@FindBy(name="lastName")
	private WebElement lastname;
	@FindBy(name="address")
	private WebElement add;
	@FindBy(name="city")
	private WebElement City;
	
	@FindBy(name="state")
	private WebElement State;
//	@FindBy(name="gender")
	private WebElement Gender;
	@FindBy(name="course")
	private WebElement Course;
	@FindBy(name="mobilenum")
	private WebElement mobile_num;
	
	@FindBy(name="next")
	private WebElement nextPage;
	
	
	public studentPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setFirstName(String firstName) {

		firstname.sendKeys(firstName);
	}
	public void setLastName(String lastName) {
		
		lastname.sendKeys(lastName);
	}
	public void setAddress(String address) {

		add.sendKeys(address);
	}
	public void setCity(String city) {
	/*Select City=new Select(driver.findElement(By.name("city")));	
	City.selectByVisibleText(city);*/
		City.sendKeys(city);
	}
	public void setState(String state) {

//		Select State=new Select(driver.findElement(By.name("state")));	
//		State.selectByVisibleText(state);
		State.sendKeys(state);
	}
	public void setGender(String gender) {
		Gender=driver.findElement(By.id(gender));
		Gender.click();
	}
	public void setCourse(String course) {
//		Select Course=new Select(driver.findElement(By.name("course")));	
//		Course.selectByVisibleText(course);
		Course.sendKeys(course);
		
	}
	public void setMobileNum(String mobilenum) {
				mobile_num.sendKeys(mobilenum);
	}
	public void setNextPage() {
				nextPage.submit();
		
	}
	
	public void navigateTo_NextPage(String firstname, String lastname, String add, String city,
			String state, String gender, String course, String mobile_num) {
		this.setFirstName(firstname);
		this.setLastName(lastname);
		this.setAddress(add);
		this.setCity(city);
		this.setState(state);
		this.setGender(gender);
		this.setCourse(course);
		this.setMobileNum(mobile_num);
		this.setNextPage();
	}
	
}

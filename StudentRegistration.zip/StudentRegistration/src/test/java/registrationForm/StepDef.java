package registrationForm;


import static org.junit.Assert.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.studentPageBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	private WebDriver driver;
	private studentPageBean studentPageBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		 driver=new ChromeDriver();
		studentPageBean=new studentPageBean(driver);
		
	}
	@Given("^open student registration form$")
	public void open_student_registration_form() throws Throwable {
		driver.get("http://localhost:8083/StudentRegForm/");	
	}

	@When("^valid student details$")
	public void valid_student_details() throws Throwable {
		studentPageBean.navigateTo_NextPage("Tom", "Jerry", "asfsdfsdg", "Hyderabad", "Telangana", "male", "ME","1234567890");
	}

	@Then("^navigate to payment form$")
	public void navigate_to_payment_form() throws Throwable {
	   driver.switchTo().alert().accept();
	   String url=driver.getCurrentUrl();
	   assertTrue(url.equals("http://localhost:8083/StudentRegForm/next"));
	}

	/*@After
	public void tearDown() {
		driver.close();
	}*/
}

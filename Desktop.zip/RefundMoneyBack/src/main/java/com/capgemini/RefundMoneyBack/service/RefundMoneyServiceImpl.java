package com.capgemini.RefundMoneyBack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RefundMoneyBack.dao.BankDao;
import com.capgemini.RefundMoneyBack.dao.RefundMoneyDao;
import com.capgemini.RefundMoneyBack.dao.TransactionDao;
import com.capgemini.RefundMoneyBack.model.BankAccount;
import com.capgemini.RefundMoneyBack.model.ReturnOrders;
import com.capgemini.RefundMoneyBack.model.Transaction;



@Service("refundmoneyservice")
@Transactional
public class RefundMoneyServiceImpl implements RefundMoneyService{
	@Autowired
	private RefundMoneyDao refundmoneydao;
	@Autowired
	private BankDao bankdao;
	@Autowired
	private TransactionDao tdao;
	public List<ReturnOrders> getAllOrders() {
		return refundmoneydao.findAll();
	}


	@Override
	public void save(ReturnOrders refund) {
		refundmoneydao.save(refund);
		
	}
	
	@Override
	public void save(BankAccount bank) {
		bankdao.save(bank);
		
	}


	@Override
	public ReturnOrders getReturn(int id) {
		// TODO Auto-generated method stub
		return refundmoneydao.getOne(id);
	}


	@Override
	public BankAccount getBank(int customerId) {
		// TODO Auto-generated method stub
		return bankdao.getBank(customerId);
	}


	@Override
	public void save(Transaction trans) {
		// TODO Auto-generated method stub
		tdao.save(trans);
	}


	@Override
	public ReturnOrders getOneOrder(Integer returnId) {
		return refundmoneydao.getOne(returnId);
	}


	


	
	
}

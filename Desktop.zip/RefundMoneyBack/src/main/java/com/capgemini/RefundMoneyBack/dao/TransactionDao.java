package com.capgemini.RefundMoneyBack.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.RefundMoneyBack.model.Transaction;
@Repository("tdao")
public interface TransactionDao extends JpaRepository<Transaction,Integer> {

}

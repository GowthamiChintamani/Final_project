package com.capgemini.RefundMoneyBack.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.RefundMoneyBack.model.RefundMoney;
import com.capgemini.RefundMoneyBack.model.ReturnOrders;
@Repository("refundmoneydao")
public interface RefundMoneyDao extends JpaRepository<ReturnOrders,Integer> {
}

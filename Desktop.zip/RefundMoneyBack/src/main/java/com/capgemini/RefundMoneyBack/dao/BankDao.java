package com.capgemini.RefundMoneyBack.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.RefundMoneyBack.model.BankAccount;

public interface BankDao extends JpaRepository<BankAccount,Integer> {
@Query("select b  from BankAccount b where b.customer.customerId=:id")
	BankAccount getBank(@Param("id") int customerId);

}

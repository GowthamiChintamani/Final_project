package com.capgemini.RefundMoneyBack.service;

import java.util.List;

import com.capgemini.RefundMoneyBack.model.BankAccount;
import com.capgemini.RefundMoneyBack.model.RefundMoney;
import com.capgemini.RefundMoneyBack.model.ReturnOrders;
import com.capgemini.RefundMoneyBack.model.Transaction;
public interface RefundMoneyService {

	public void save(ReturnOrders refund);
	public List<ReturnOrders> getAllOrders();
	public ReturnOrders getReturn(int id);
	public BankAccount getBank(int customerId);
	public void save(Transaction trans);
	public void save(BankAccount bank);
	
	public ReturnOrders getOneOrder(Integer returnId);

}

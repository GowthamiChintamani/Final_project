package com.capgemini.RefundMoneyBack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.RefundMoneyBack.model.BankAccount;
import com.capgemini.RefundMoneyBack.model.Customer;
import com.capgemini.RefundMoneyBack.model.RefundMoney;
import com.capgemini.RefundMoneyBack.model.ReturnOrders;
import com.capgemini.RefundMoneyBack.model.Transaction;
import com.capgemini.RefundMoneyBack.service.RefundMoneyService;

@RestController
@RequestMapping("/api/v1")
public class RefundMoneyController {
	
	@Autowired
	private RefundMoneyService refundmoneyservice;
	
	@GetMapping("refund")
	public ResponseEntity<List<ReturnOrders>> getAllOrders(){
		List<ReturnOrders> orders= refundmoneyservice.getAllOrders();
		/*if(orders.isEmpty()||orders==null)
			{
			
			return new ResponseEntity("Sorry!orders not available for refund !",HttpStatus.NOT_FOUND);
	}*/
		return new ResponseEntity<List<ReturnOrders>>(orders,HttpStatus.OK);
	}
	
	@GetMapping("refund/{returnId}")
	public ResponseEntity<ReturnOrders> getOneOrder(@PathVariable("returnId") Integer returnId){
		ReturnOrders orders= refundmoneyservice.getOneOrder(returnId);
		
		return new ResponseEntity<ReturnOrders>(orders,HttpStatus.OK);
	}
	
	@PutMapping("refundMoney")
	public ResponseEntity<Transaction> getReturn(@RequestBody ReturnOrders retur){
		
		Transaction trans=retur.getTransaction();	
		 Customer cust=retur.getCustomer();
		 //double amount=trans.getAmount();
		 
		 BankAccount bank=refundmoneyservice.getBank(cust.getCustomerId());
		 
		 
		 
		 
		 
		if(trans.getModeOfPurchase().equals("online purchase"))
		{
			bank.setBalance(bank.getBalance()+trans.getAmount());
		}
		refundmoneyservice.save(trans);
		refundmoneyservice.save(bank);
		
		return new ResponseEntity<Transaction>(trans,HttpStatus.OK);
	}
	

	
	
	
	
	
}

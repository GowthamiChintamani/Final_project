package com.capgemini.RefundMoneyFront.model;

import java.util.Date;
import java.util.List;
/*
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.UniqueConstraint;*/

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

//@Entity
//@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler", "created"}) 
public class Customer {

	//@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int customerId;
	private String customerName;
	private String phoneNumber;
	//@Column(unique=true)
	private String emailId;
	private Date dateOfBirth;
	private String password;
	private Date lastLogin;
	private boolean isActive;
	//@OneToMany(targetEntity = BankAccount.class, mappedBy = "customer")
	private List<BankAccount> bank;
	//@OneToMany(targetEntity = ManagingCart.class, mappedBy = "customer")
	private List<ManagingCart> managingCart;
	//@OneToMany(targetEntity = Order.class, mappedBy = "customer")
	private List<Order> order;

	public Customer() {
		
	}

	




	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	

	public boolean isActive() {
		return isActive;
	}



	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}



	

	public List<BankAccount> getBank() {
		return bank;
	}

	public void setBank(List<BankAccount> bank) {
		this.bank = bank;
	}

	public List<ManagingCart> getManagingCart() {
		return managingCart;
	}

	public void setManagingCart(List<ManagingCart> managingCart) {
		this.managingCart = managingCart;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}





	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", phoneNumber=" + phoneNumber
				+ ", emailId=" + emailId + ", dateOfBirth=" + dateOfBirth + ", password=" + password + ", lastLogin="
				+ lastLogin + ", isActive=" + isActive + ", bank=" + bank + ", managingCart=" + managingCart
				+ ", order=" + order + "]";
	}






	public Customer(int customerId, String customerName, String phoneNumber, String emailId, Date dateOfBirth,
			String password, Date lastLogin, boolean isActive, List<BankAccount> bank, List<ManagingCart> managingCart,
			List<Order> order) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.password = password;
		this.lastLogin = lastLogin;
		this.isActive = isActive;
		this.bank = bank;
		this.managingCart = managingCart;
		this.order = order;
	}


	
	
	

}

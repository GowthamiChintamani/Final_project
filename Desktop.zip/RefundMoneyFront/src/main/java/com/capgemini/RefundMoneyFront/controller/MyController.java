package com.capgemini.RefundMoneyFront.controller;


import java.util.HashMap;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.capgemini.RefundMoneyFront.model.RefundMoney;
import com.capgemini.RefundMoneyFront.model.ReturnOrders;




@Controller
public class MyController {
	/*@RequestMapping("/")
	public String refund() {
		//System.out.println("hello");
		return "RefundMoneyCap";
	}*/
	
	@RequestMapping("/Refund")
	public String getRefundMoney(ModelMap map,@ModelAttribute("ReturnOrders") ReturnOrders refund) {
		
		
		final String uri="http://localhost:8084/RefundMoneyBack/api/v1/refund";
		RestTemplate restTemplate=new RestTemplate();
		
		ReturnOrders[] refund1= restTemplate.getForObject(uri, ReturnOrders[].class);
		
		
		map.put("refunds",refund1);
		map.put("refund", new RefundMoney());
		
		return "RefundMoneyCap";
	}
	
	@RequestMapping("/refund/{returnId}")
	public String processRefund(@PathVariable("returnId")String re, ModelMap map) {//, @ModelAttribute("returnOrders") ReturnOrders refund, BindingResult result) {
		
		//boolean flag=true;
		//int ret=refund.getReturnId();
		
		//if(flag) {
		Integer ret = Integer.parseInt(re);
		final String uri2="http://localhost:8084/RefundMoneyBack/api/v1/refund/{returnId}";
		
		RestTemplate restTemplate1=new RestTemplate();
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("returnId", ret);
		
		ReturnOrders retur= restTemplate1.getForObject(uri2, ReturnOrders.class,params);
		
		
		final String uri1="http://localhost:8084/RefundMoneyBack/api/v1/refundMoney";
		
		RestTemplate restTemplate2=new RestTemplate();
		
		//ReturnOrders retur= restTemplate1.getForObject(uri1, ReturnOrders.class);
		
	//	final String uri="http://localhost:8084/RefundMoneyBack/api/v1/refund";
	//	RestTemplate restTemplate=new RestTemplate();
	//	restTemplate.postForEntity(uri,retur,ReturnOrders.class);
		
		restTemplate2.put(uri1,retur,ReturnOrders.class);
		
		/*}
		else {
			
		}*/
		
		return "RefundMoneyCap";
	}
	
	@RequestMapping("/RefundMoneyCap")
	public String getRefundMoneyCap(ModelMap map) {
		
		
		final String uri="http://localhost:8084/RefundMoneyBack/api/v1/refund";
		RestTemplate restTemplate=new RestTemplate();
		
		ReturnOrders[] refund1= restTemplate.getForObject(uri, ReturnOrders[].class);
		
		
		map.put("refunds",refund1);
		map.put("refund", new RefundMoney());
		
		return "RefundMoneyCap";
	}
	
}

function MerchantValidation(){
	
	var x = document.getElementsByName("merchantValidation");
    if (x == "true") {
        alert("refund successful");
        return true;
    }
     else if (x == "false") {
        // no checked
       /* var msg = '<span style="color:red;">invalid!</span><br /><br />';
        document.getElementById('msg').innerHTML = msg;*/
    	  alert("not refundable");
        return false;
    }
}
function reset_msg() {
    document.getElementById('msg').innerHTML = '';
}




/*<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Radio button: full validation example with javascript</title>
        <script>
            function send() {
                var genders = document.getElementsByName("gender");
                if (genders[0].checked == true) {
                    alert("Your gender is male");
                } else if (genders[1].checked == true) {
                    alert("Your gender is female");
                } else {
                    // no checked
                    var msg = '<span style="color:red;">You must select your gender!</span><br /><br />';
                    document.getElementById('msg').innerHTML = msg;
                    return false;
                }
                return true;
            }

            function reset_msg() {
                document.getElementById('msg').innerHTML = '';
            }*/
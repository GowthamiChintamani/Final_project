package com.capgemini.CouponGenFront.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MyController {
	@RequestMapping("/")
	public String deepthi() {
		//System.out.println("hello");
		return "GenerateCoupon";
	}
	
	/*@RequestMapping("/GenerateCoupon")
	public String getPilotForm(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
		final String uri="http://localhost:8088/CouponGenBack/api/v1/coupons";
		RestTemplate restTemplate=new RestTemplate();
		
		Refund[] refund= restTemplate.getForObject(uri, Refund[].class);
		
		
		map.put("refund",refund);
		map.put("refund", new Refund());
		
		return "GenerateCoupon";
	}
	*/
}

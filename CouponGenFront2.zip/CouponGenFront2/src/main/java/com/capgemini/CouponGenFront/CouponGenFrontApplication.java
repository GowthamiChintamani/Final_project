package com.capgemini.CouponGenFront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouponGenFrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(CouponGenFrontApplication.class, args);
	}
}

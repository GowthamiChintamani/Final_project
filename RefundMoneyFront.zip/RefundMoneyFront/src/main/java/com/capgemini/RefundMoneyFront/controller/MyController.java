package com.capgemini.RefundMoneyFront.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.RefundMoneyFront.model.RefundMoney;




@Controller
public class MyController {
	/*@RequestMapping("/")
	public String refund() {
		//System.out.println("hello");
		return "RefundMoneyCap";
	}*/
	
	@RequestMapping("Refund")
	public String getRefundMoney(ModelMap map,@ModelAttribute("refund") RefundMoney refund) {
		
		
		final String uri="http://localhost:8087/RefundMoneyBack/api/v1/refund";
		RestTemplate restTemplate=new RestTemplate();
		
		RefundMoney[] refund1= restTemplate.getForObject(uri, RefundMoney[].class);
		
		
		map.put("refunds",refund1);
		map.put("refund", new RefundMoney());
		
		return "RefundMoneyCap";
	}
	
}
package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface PilotService {
	
	public List<Pilot> getAll();

	public Pilot findPilot(Integer pilotId);

	public void deletePilot(Integer pilotId);

	

	public void updatePilot(Pilot pilot);
	
}

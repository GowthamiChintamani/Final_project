package com.capgemini.CouponGenBack.service;

import java.util.List;

import com.capgemini.CouponGenBack.model.Coupons;
public interface CouponService {

	public void save(Coupons coupons);
	public List<Coupons> getAll();
	
}

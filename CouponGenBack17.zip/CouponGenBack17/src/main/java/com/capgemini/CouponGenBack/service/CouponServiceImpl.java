package com.capgemini.CouponGenBack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.CouponGenBack.dao.CouponDao;
import com.capgemini.CouponGenBack.model.Coupons;



@Service("couponservice")
@Transactional
public class CouponServiceImpl implements CouponService{
	@Autowired
	private CouponDao coupondao;

	
	public List<Coupons> getAll() {
		return coupondao.findAll();
	}

	
	public void save(Coupons coupons) {
		// TODO Auto-generated method stub
		coupondao.save(coupons);
	}
}

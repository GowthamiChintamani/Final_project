package com.capgemini.CouponGenFront.model;


public class Refund {

	private int refundId;
	private int merchantId;
	private int returnId;
	private int transactionId;
	private long accountNo;
	private int customerId;
	private String modeOfTransaction;
	public int getRefundId() {
		return refundId;
	}
	public void setRefundId(int refundId) {
		this.refundId = refundId;
	}
	public int getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}
	public int getReturnId() {
		return returnId;
	}
	public void setReturnId(int returnId) {
		this.returnId = returnId;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getModeOfTransaction() {
		return modeOfTransaction;
	}
	public void setModeOfTransaction(String modeOfTransaction) {
		this.modeOfTransaction = modeOfTransaction;
	}
	public Refund(int refundId, int merchantId, int returnId, int transactionId, long accountNo, int customerId,
			String modeOfTransaction) {
		super();
		this.refundId = refundId;
		this.merchantId = merchantId;
		this.returnId = returnId;
		this.transactionId = transactionId;
		this.accountNo = accountNo;
		this.customerId = customerId;
		this.modeOfTransaction = modeOfTransaction;
	}
	public Refund() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Refund [refundId=" + refundId + ", merchantId=" + merchantId + ", returnId=" + returnId
				+ ", transactionId=" + transactionId + ", accountNo=" + accountNo + ", customerId=" + customerId
				+ ", modeOfTransaction=" + modeOfTransaction + "]";
	}
	
}



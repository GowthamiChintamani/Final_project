package com.capgemini.CouponGenFront.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.CouponGenFront.model.Refund;


@Controller
public class MyController {
	@RequestMapping("/")
	public String deepthi() {
		//System.out.println("hello");
		return "GenerateCoupon";
	}
	
	@RequestMapping("/GenerateCoupon")
	public String getPilotForm(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
		final String uri="http://localhost:8087/CouponGenBack/api/v1/refund";
		RestTemplate restTemplate=new RestTemplate();
		
		Refund[] refund= restTemplate.getForObject(uri, Refund[].class);
		
		
		map.put("refund",refund);
		map.put("refund", new Refund());
		
		return "GenerateCoupon";
	}
	
}

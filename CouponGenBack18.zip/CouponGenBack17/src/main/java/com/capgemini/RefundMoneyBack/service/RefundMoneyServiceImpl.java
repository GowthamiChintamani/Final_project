package com.capgemini.RefundMoneyBack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.RefundMoneyBack.dao.RefundMoneyDao;
import com.capgemini.RefundMoneyBack.model.RefundMoney;



@Service("refundmoneyservice")
@Transactional
public class RefundMoneyServiceImpl implements RefundMoneyService{
	@Autowired
	private RefundMoneyDao refundmoneydao;

	
	public List<RefundMoney> getAllOrders() {
		return refundmoneydao.findAll();
	}


	


	
	/*public void save(RefundMoney coupons) {
		// TODO Auto-generated method stub
		coupondao.save(coupons);
	}*/
}

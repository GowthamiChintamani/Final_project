package com.capgemini.RefundMoneyBack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.RefundMoneyBack.model.RefundMoney;
import com.capgemini.RefundMoneyBack.service.RefundMoneyService;

@RestController
@RequestMapping("/api/v1")
public class RefundMoneyController {
	
	@Autowired
	private RefundMoneyService refundmoneyservice;
	
	@GetMapping("/refund")
	public ResponseEntity<List<RefundMoney>> getAllOrders(){
		List<RefundMoney> orders= refundmoneyservice.getAllOrders();
		if(orders.isEmpty()||orders==null)
			{
			
			return new ResponseEntity("Sorry!orders not available for refund !",HttpStatus.NOT_FOUND);
	}
		return new ResponseEntity<List<RefundMoney>>(orders,HttpStatus.OK);
	}
	
	/*@PostMapping("/coupons")
	public ResponseEntity<RefundMoney> createCoupon(@RequestBody RefundMoney coupons){
		couponservice.save(coupons);
		
		return new ResponseEntity<RefundMoney>(coupons,HttpStatus.OK);
	}
*/
	
}

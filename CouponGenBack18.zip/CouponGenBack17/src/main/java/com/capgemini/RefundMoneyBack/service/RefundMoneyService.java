package com.capgemini.RefundMoneyBack.service;

import java.util.List;

import com.capgemini.RefundMoneyBack.model.RefundMoney;
public interface RefundMoneyService {

	public void save(RefundMoney refund);
	public List<RefundMoney> getAllOrders();
	
}

 package org.cap.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.IAccountService;
import org.cap.service.ILoginService;
import org.cap.service.ITransactionservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {
	@Autowired
private ILoginService loginService;
	@Autowired
	private IAccountService acccountService;
	@Autowired
	private ITransactionservice transactionService;
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, @RequestParam("customerId")String customerId,@RequestParam("customerPwd")String customerPwd,HttpSession session) {
		Integer custId=Integer.parseInt(customerId);
		
		if(loginService.validateLogin(custId,customerPwd)) {
			session.setAttribute("custId", custId);
			String custName=loginService.getCustomerName(custId);
			map.put("custName", custName);
			
			return "main";
		}
		
		return "redirect:/";
	}
	
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("account", new Account());
		return "createAccount";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session,@ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);
		//Customer customer=new Customer();
		//customer.setCustomerId(customerId);
		account.setCustomer(customer);
		account.setStatus("active");
		acccountService.createAccount(account);
		
		return "redirect:createAccount";
	}
	

	@RequestMapping("/showBalance")
	public String showbalancepage(ModelMap map,HttpSession session) {
		Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts= acccountService.getAccountWithBalance(custId);
		map.put("accounts", accounts);
		return "showBalance";
	}
	
	@RequestMapping("/deposit")
	public String deposit(ModelMap map,HttpSession session) {

		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Account> accounts = acccountService.getAllAccounts(customerId);
		map.put("transaction", new Transaction());
		map.put("accounts", accounts);
		
		return "depositWithdraw";
	}
	
	
	
	@RequestMapping("/depositwithdraw")
	public String depositwithdraw(@RequestParam("fromAcc")int accountId,@ModelAttribute("transaction")Transaction transaction,HttpSession session) {
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);

		transaction.setCustomer(customer);
		transaction.setTransactionDate(new Date());
		transaction.setStatus("completed");
		Account account = new Account();
		account.setAccountId(accountId);
		transaction.setFromAccount(account);
		transaction.setToAccount(null);
		
		transactionService.createAccount(transaction);
		
		return "redirect:/deposit";
	
	}
	
	@RequestMapping("/fundTransfer")
	public String fundtransfer(ModelMap map,HttpSession session) {
Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Account> accounts = acccountService.getAllAccounts(customerId);
		map.put("transaction1", new Transaction());
		map.put("accounts", accounts);
		List<Account> account = acccountService.getToAccounts(customerId);
		map.put("account", account);
		return "fundTransfer";
	
	}
	
	@RequestMapping("/doTransfer")
	public String doTransfer(@RequestParam("fromAcc")int frmaccountId,@RequestParam("toAcc")int toaccountId,@ModelAttribute("transaction1")Transaction transaction1,HttpSession session) {
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);
		transaction1.setCustomer(customer);
		transaction1.setTransactionDate(new Date());
		transaction1.setStatus("Success");
		transaction1.setTransactionType("debit");                                                                                                                                
		 
			Account fromaccount = acccountService.findAccount(frmaccountId);
					transaction1.setFromAccount(fromaccount);
					Account toaccount = acccountService.findAccount(toaccountId);
					transaction1.setToAccount(toaccount);
					
					
					transactionService.fundTransfer(transaction1); 
			 

	
		
		return "redirect:/fundTransfer";
	}  
	@RequestMapping("/transactionSummary")
	public String summaryPage(HttpSession session,ModelMap map) {
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		List<Transaction> transactions=transactionService.getTransactions(customerId);
		map.put("transDate", transactions);
		map.put("listoftrans", null);
		return "transactionSummary";
	}
	
	@RequestMapping("/showtransaction")
	public String transsummary(
			@RequestParam("date1")String date1,
			@RequestParam("date2")String date2,
			HttpSession session,ModelMap map) throws ParseException {
		
		System.out.println(date1);
		System.out.println(date2);
		
		Date d1=new SimpleDateFormat("yyyy-MM-dd").parse(date1);
		Date d2=new SimpleDateFormat("yyyy-MM-dd").parse(date2);	
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		List<Transaction> transaction=transactionService.getDatedTransactions(customerId,d1,d2);
		List<Transaction> transactionDates=transactionService.getTransactions(customerId);
		
		map.put("listoftrans", transaction);
		map.put("transDate", transactionDates);
		
		return "transactionSummary";
	}
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
session.invalidate();
		return "redirect:/";
	}
}

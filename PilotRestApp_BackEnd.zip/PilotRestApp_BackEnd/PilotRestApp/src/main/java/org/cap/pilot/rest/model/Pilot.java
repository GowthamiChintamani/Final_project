package org.cap.pilot.rest.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Pilot {
	@Id
	@GeneratedValue
	
	private int pilotid;
	@NotEmpty(message="*please enter firstName.")
	private String firstname;
	private String lastname;
	
	@NotNull(message="* Please enter Date Of Birth.")
	@Past(message="* Please enter past date.")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date dateofbirth;
	
	@Future(message="* Please nter future date.")
	@JsonFormat(pattern="dd-MMM-yyyy")
	private Date dateofjoining;
	private Boolean iscertified;
	
	@Range(min=10000,max=200000,message="*Salary should be between 10000 and 2laks.")
	private double salary;
	
	public Pilot() {
		
	}

	public int getPilotid() {
		return pilotid;
	}

	public void setPilotid(int pilotid) {
		this.pilotid = pilotid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	public Date getDateofjoining() {
		return dateofjoining;
	}

	public void setDateofjoining(Date dateofjoining) {
		this.dateofjoining = dateofjoining;
	}

	public Boolean getIscertified() {
		return iscertified;
	}

	public void setIscertified(Boolean iscertified) {
		this.iscertified = iscertified;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Pilot(int pilotid, @NotEmpty(message = "*please enter firstName.") String firstname, String lastname,
			@NotNull(message = "* Please enter Date Of Birth.") @Past(message = "* Please enter past date.") Date dateofbirth,
			@Future(message = "* Please nter future date.") Date dateofjoining, Boolean iscertified,
			@Range(min = 10000, max = 200000, message = "*Salary should be between 10000 and 2laks.") double salary) {
		super();
		this.pilotid = pilotid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dateofbirth = dateofbirth;
		this.dateofjoining = dateofjoining;
		this.iscertified = iscertified;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Pilot [pilotid=" + pilotid + ", firstname=" + firstname + ", lastname=" + lastname + ", dateofbirth="
				+ dateofbirth + ", dateofjoining=" + dateofjoining + ", iscertified=" + iscertified + ", salary="
				+ salary + "]";
	}

	
	

}

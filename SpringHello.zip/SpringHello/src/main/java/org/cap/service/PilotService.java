package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("pilotService")
public class PilotService implements IPilotService {
@Autowired
private IPilotDao pilotDao;
	@Override
	public List<Pilot> getAllpilots() {
		// TODO Auto-generated method stub
		return pilotDao.getAllpilots();
	}

}

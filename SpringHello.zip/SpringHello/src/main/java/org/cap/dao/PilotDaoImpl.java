package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
@Repository("pilotDao")
public class PilotDaoImpl implements IPilotDao{
private static AtomicInteger pilotId=new AtomicInteger(1000);

private static List<Pilot> pilots=dummyDbPilot();

private static List<Pilot> dummyDbPilot(){
	List<Pilot> pilots=new ArrayList<>();
	pilots.add(new Pilot(pilotId.incrementAndGet(),"tom","jerry",new Date(13-03-1997),new Date(),true,23000));
	pilots.add(new Pilot(pilotId.incrementAndGet(),"patrik","spongebob",new Date(14-03-1998),new Date(),true,4500));
	pilots.add(new Pilot(pilotId.incrementAndGet(),"gen","kin",new Date(13-03-2000),new Date(),true,29000));
	return pilots;
}
	@Override
	public List<Pilot> getAllpilots() {
		// TODO Auto-generated method stub
		return pilots;
	}

}

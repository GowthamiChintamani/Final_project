package org.cap.model;
import java.util.Date;


import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Pilot {

private int pilotId;
private String firstName;
private String lastName;
private Date DOB;
private Date DOJ;
private boolean isCertified;
private double salary;


public int getPilotId() {
	return pilotId;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Date getDOB() {
	return DOB;
}
public void setDOB(Date dOB) {
	DOB = dOB;
}
public Date getDOJ() {
	return DOJ;
}
public void setDOJ(Date dOJ) {
	DOJ = dOJ;
}
public boolean getIsCertified() {
	return isCertified;
}
public void setIsCertified(boolean isCertified) {
	this.isCertified = isCertified;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", DOB=" + DOB
			+ ", DOJ=" + DOJ + ", isCertified=" + isCertified + ", salary=" + salary + "]";
}
public Pilot(int pilotId, String firstName, String lastName, Date dOB, Date dOJ, boolean isCertified, double salary) {
	super();
	this.pilotId = pilotId;
	this.firstName = firstName;
	this.lastName = lastName;
	DOB = dOB;
	DOJ = dOJ;
	this.isCertified = isCertified;
	this.salary = salary;
}
public Pilot()
{
	
}


}

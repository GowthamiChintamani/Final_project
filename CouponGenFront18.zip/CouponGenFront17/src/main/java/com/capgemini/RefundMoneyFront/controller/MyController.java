package com.capgemini.RefundMoneyFront.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.RefundMoneyFront.model.Refund;


@Controller
public class MyController {
	@RequestMapping("/")
	public String refund() {
		//System.out.println("hello");
		return "RefundMoney";
	}
	
	@RequestMapping("/RefundMoney")
	public String getRefundMoney(ModelMap map) {
		
		
		final String uri="http://localhost:8087/CouponGenBack/api/v1/refund";
		RestTemplate restTemplate=new RestTemplate();
		
		Refund[] refund= restTemplate.getForObject(uri, Refund[].class);
		
		
		map.put("refund",refund);
		map.put("refund", new Refund());
		
		return "RefundMoney";
	}
	
}

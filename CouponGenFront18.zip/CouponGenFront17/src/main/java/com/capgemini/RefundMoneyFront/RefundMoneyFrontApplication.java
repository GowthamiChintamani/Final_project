package com.capgemini.RefundMoneyFront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefundMoneyFrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefundMoneyFrontApplication.class, args);
	}
}

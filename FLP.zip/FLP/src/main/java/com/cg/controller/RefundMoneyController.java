package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.ReturnOrders;
import com.cg.service.RefundMoneyService;



@RestController
@RequestMapping("/api/v1")
public class RefundMoneyController {
	@Autowired
	private RefundMoneyService refundService;
	@GetMapping("/ReturnOrders")
	public ResponseEntity<List<ReturnOrders>> getAllreturnId(){
		List<ReturnOrders> discounts= refundService.getreturnIds();
		if(discounts.isEmpty()||discounts==null)
			{
			System.out.println("Sharath");
			
			return new ResponseEntity
				("Sorry! Discount details not available!",HttpStatus.NOT_FOUND);
	}
		return new ResponseEntity<List<ReturnOrders>>(discounts,HttpStatus.OK);
	}
	
}

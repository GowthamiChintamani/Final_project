package com.capgemini.RefundMoneyBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefundMoneyBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefundMoneyBackApplication.class, args);
	}
}
